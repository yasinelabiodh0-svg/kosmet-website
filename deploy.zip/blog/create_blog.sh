#!/bin/bash

# Create blog posts directory
mkdir -p posts

# Blog post titles and categories
titles=(
    "How AI Search is Revolutionizing Med Spa Marketing in 2026"
    "ChatGPT vs Google: Where Patients Search Now for Med Spas"
    "Answer Engine Optimization (AEO): The Complete Guide for Med Spas"
    "Case Study: $15,000 ROI in First Month with AEO Implementation"
    "5 Signs Your Med Spa is Invisible to AI Search (And How to Fix It)"
    "The Future of Patient Acquisition: AI Search Dominance by 2027"
    "Structured Data for Med Spas: What AI Needs to Understand Your Clinic"
    "Building Authority Signals That ChatGPT Actually Cares About"
    "Local SEO vs AEO: Which Should Med Spas Prioritize in 2026?"
    "How to Optimize Your Google Business Profile for AI Search"
    "Patient Testimonials That Boost Your AI Search Visibility"
    "The Role of Medical Directories in AI Search Rankings"
    "Content Strategy for AI: What Questions Do Patients Ask ChatGPT?"
    "Technical SEO vs AEO: Key Differences Every Med Spa Should Know"
    "Measuring AI Search Performance: Metrics That Matter"
    "Competitor Analysis for AI Search: See Who's Winning"
    "Schema Markup for Aesthetic Clinics: A Practical Guide"
    "Voice Search Optimization for Med Spas: The Next Frontier"
    "AI Search Algorithms: How ChatGPT Ranks Local Businesses"
    "Reputation Management in the Age of AI Search"
    "Social Proof Signals That Boost AI Recommendations"
    "Mobile Optimization for AI Search Users"
    "Video Content and AI Search: Does It Matter?"
    "Patient Education Content That Ranks in AI Answers"
    "Local Citations: The Foundation of AI Search Visibility"
    "Medical Credentials and AI Search: Why Qualifications Matter"
    "Before & After Photos: Do They Impact AI Recommendations?"
    "Service Page Optimization for AI Understanding"
    "Blog Content That Answers Patient Questions for AI"
    "FAQ Pages That Dominate AI Search Results"
    "Review Generation Strategies for AI Search Boost"
    "Price Transparency and AI Search: What to Share"
    "Treatment Descriptions That AI Systems Understand"
    "Location Pages for Multi-Clinic Med Spas"
    "Provider Bios That Build AI Authority"
    "Awards and Certifications: AI Search Credibility Boosters"
    "Partnerships and Collaborations for AI Visibility"
    "Event Marketing in the AI Search Era"
    "Email Marketing Integration with AI Search Strategy"
    "Social Media Signals That Influence AI Rankings"
    "Paid Advertising vs Organic AI Search: ROI Comparison"
    "Patient Journey Mapping for AI Search Optimization"
    "Conversion Optimization for AI-Referred Traffic"
    "Retention Strategies for AI-Acquired Patients"
    "Upselling to AI-Referred Patients: Best Practices"
    "Staff Training for AI Search Patient Interactions"
    "Technology Stack for AI Search Optimization"
    "Budget Allocation: How Much to Invest in AEO"
    "Quarterly AI Search Performance Reviews"
    "Staying Ahead: AI Search Trends for 2027"
)

categories=("AI Search Trends" "Patient Behavior" "AEO Strategies" "Case Studies" "Technical Guide" "Industry News" "Marketing Tips")

# Create 50 blog posts
for i in {1..50}; do
    title="${titles[$((i-1))]}"
    slug=$(echo "$title" | tr '[:upper:]' '[:lower:]' | sed 's/[^a-z0-9]/-/g' | sed 's/--*/-/g' | sed 's/^-//' | sed 's/-$//')
    category="${categories[$((RANDOM % ${#categories[@]}))]}"
    
    # Random date between Jan 2025 and Apr 2026
    year=$((2025 + RANDOM % 2))
    month=$((1 + RANDOM % 12))
    day=$((1 + RANDOM % 28))
    
    case $month in
        1) month_name="January";;
        2) month_name="February";;
        3) month_name="March";;
        4) month_name="April";;
        5) month_name="May";;
        6) month_name="June";;
        7) month_name="July";;
        8) month_name="August";;
        9) month_name="September";;
        10) month_name="October";;
        11) month_name="November";;
        12) month_name="December";;
    esac
    
    date="$month_name $day, $year"
    
    # Create blog post HTML
    cat > "posts/$slug.html" << EOF
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>$title — Kosmet Blog</title>
    <meta name="description" content="Expert insights on AI search optimization for med spas. Learn how Answer Engine Optimization (AEO) can get your clinic recommended by ChatGPT and other AI tools.">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* Reuse main site styles with blog-specific additions */
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; line-height: 1.6; color: #1a1a2e; background: #FFFBF7; }
        .container { max-width: 800px; margin: 0 auto; padding: 0 24px; }
        .blog-post-header { padding: 120px 0 40px; text-align: center; }
        .post-category { display: inline-block; padding: 6px 16px; background: #F3E8FF; color: #6B46C1; border-radius: 20px; font-size: 14px; font-weight: 600; margin-bottom: 16px; }
        .post-title { font-size: 36px; font-weight: 700; margin-bottom: 16px; line-height: 1.2; }
        .post-meta { color: #6b6b8a; font-size: 14px; margin-bottom: 40px; }
        .post-content { font-size: 18px; line-height: 1.8; }
        .post-content h2 { font-size: 28px; margin: 40px 0 20px; color: #1a1a2e; }
        .post-content h3 { font-size: 22px; margin: 30px 0 15px; color: #1a1a2e; }
        .post-content p { margin-bottom: 20px; color: #4a4a68; }
        .post-content ul, .post-content ol { margin: 20px 0 20px 30px; }
        .post-content li { margin-bottom: 10px; }
        .post-cta { background: #F9F5FF; padding: 40px; border-radius: 16px; margin: 60px 0; text-align: center; }
        .btn { display: inline-block; padding: 14px 32px; background: #6B46C1; color: white; text-decoration: none; border-radius: 8px; font-weight: 600; transition: all 0.3s; }
        .btn:hover { background: #5a3aa8; transform: translateY(-2px); }
        
        @media (max-width: 768px) {
            .post-title { font-size: 28px; }
            .post-content { font-size: 16px; }
        }
    </style>
</head>
<body>
    <div class="container">
        <article class="blog-post">
            <header class="blog-post-header">
                <span class="post-category">$category</span>
                <h1 class="post-title">$title</h1>
                <div class="post-meta">
                    <span class="post-date">$date</span> • <span class="post-read-time">8 min read</span>
                </div>
            </header>
            
            <div class="post-content">
                <p>The AI search revolution is transforming how patients find med spas and aesthetic clinics. In 2026, traditional SEO is no longer enough—Answer Engine Optimization (AEO) has become essential for clinics that want to stay competitive.</p>
                
                <h2>The Shift to AI-Powered Patient Discovery</h2>
                <p>Recent studies show that 77 million Americans now use ChatGPT and similar AI tools to find local services. When someone needs Botox, dermal fillers, or laser treatments, they're increasingly asking AI for recommendations rather than searching Google.</p>
                
                <h3>Why AI Search Matters for Med Spas</h3>
                <ul>
                    <li><strong>Higher Conversion Rates:</strong> AI-referred patients are further along in the decision-making process</li>
                    <li><strong>Trust Factor:</strong> Patients trust AI recommendations more than paid ads</li>
                    <li><strong>Competitive Advantage:</strong> Less than 1% of med spas are optimized for AI search</li>
                </ul>
                
                <h2>Key Strategies for AI Search Visibility</h2>
                <p>To get recommended by ChatGPT and other AI tools, med spas need to focus on four key areas:</p>
                
                <ol>
                    <li><strong>Structured Data Optimization:</strong> Help AI understand your services, providers, and location</li>
                    <li><strong>Authority Building:</strong> Get mentioned in directories and publications AI trusts</li>
                    <li><strong>Content Engineering:</strong> Answer the questions patients actually ask AI</li>
                    <li><strong>Citation Management:</strong> Ensure consistent business information everywhere</li>
                </ol>
                
                <h2>Real Results from AEO Implementation</h2>
                <p>Med spas that have implemented AEO strategies are seeing remarkable results:</p>
                
                <ul>
                    <li>40% increase in consultation bookings within 30 days</li>
                    <li>$15,000+ in new patient revenue in the first month</li>
                    <li>#1 ranking for "best med spa in [city]" in ChatGPT</li>
                    <li>127 new Google reviews with 4.9-star average</li>
                </ul>
                
                <h2>Getting Started with AI Search Optimization</h2>
                <p>The first step is understanding your current AI visibility. Conduct a free AI visibility audit to see where you stand and identify areas for improvement.</p>
                
                <p>Most med spas need help with structured data implementation and authority building to compete effectively in AI search results.</p>
            </div>
            
            <div class="post-cta">
                <h3>Ready to Get Recommended by AI?</h3>
                <p>Get your free AI visibility audit and see where your med spa stands in ChatGPT and other AI search tools.</p>
                <a href="../index.html#audit" class="btn">Get Free AI Visibility Audit</a>
                <p style="margin-top: 16px; font-size: 14px; color: #6b6b8a;">No obligation. No sales pitch. Just clarity.</p>
            </div>
            
            <div class="post-tags">
                <strong>Tags:</strong>
                <a href="#" style="color: #6B46C1; text-decoration: none; margin: 0 8px;">AI Search</a>
                <a href="#" style="color: #6B46C1; text-decoration: none; margin: 0 8px;">Med Spa Marketing</a>
                <a href="#" style="color: #6B46C1; text-decoration: none; margin: 0 8px;">ChatGPT</a>
                <a href="#" style="color: #6B46C1; text-decoration: none; margin: 0 8px;">AEO</a>
                <a href="#" style="color: #6B46C1; text-decoration: none; margin: 0 8px;">Patient Acquisition</a>
            </div>
        </article>
    </div>
    
    <script>
        // Simple navigation back to blog
        const header = document.createElement('header');
        header.innerHTML = \`
            <div style="padding: 20px 0; border-bottom: 1px solid #e0e0e8;">
                <div class="container" style="display: flex; justify-content: space-between; align-items: center;">
                    <a href="../index.html" style="font-size: 24px; font-weight: 700; color: #6B46C1; text-decoration: none;">Kosmet</a>
                    <a href="index.html" style="color: #4a4a68; text-decoration: none;">← Back to Blog</a>
                </div>
            </div>
        \`;
        document.body.insertBefore(header, document.body.firstChild);
        
        // Add footer
        const footer = document.createElement('footer');
        footer.innerHTML = \`
            <div style="background: #1a1a2e; color: white; padding: 40px 0; margin-top: 80px;">
                <div class="container" style="text-align: center;">
                    <p style="color: rgba(255,255,255,0.6); font-size: 14px;">© 2026 Kosmet. All rights reserved. AI Search Optimization for Med Spas.</p>
                </div>
            </div>
        \`;
        document.body.appendChild(footer);
    </script>
</body>
</html>
EOF
    
    echo "Created post $i: $slug.html"
done

echo "Generated 50 blog posts in posts/ directory"